package com.zybooks.johnchampy_option2_eventtracker;

import java.util.List;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class EventAdapter extends ArrayAdapter<Event>
{

    public EventAdapter(Context context, List<Event> events)
    {
        super(context, 0, events);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent)
    {
        Event event = getItem(position);
        if(convertView == null)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.events_display, parent, false);

        TextView eventname = convertView.findViewById(R.id.EventName);
        TextView date = convertView.findViewById(R.id.editTextDate);

        eventname.setText(event.getEventName());
        date.setText(event.getDate());

        return convertView;
    }
}
