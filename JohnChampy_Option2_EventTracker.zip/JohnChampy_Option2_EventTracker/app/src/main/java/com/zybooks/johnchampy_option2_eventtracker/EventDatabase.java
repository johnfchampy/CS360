package com.zybooks.johnchampy_option2_eventtracker;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class EventDatabase extends SQLiteOpenHelper {
    private static EventDatabase eventDatabase;
    private static final String DATABASE_NAME = "Event.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME= "Events";
    private static final String COL_1 = "ID";
    private static final String COL_2 = "EVENTNAME";
    private static final String COL_3 = "DATE";
    private static final String COL_4 = "DETAILS";

    public EventDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    public static EventDatabase instanceOfDatabase(Context context)
    {
        if(eventDatabase == null)
            eventDatabase = new EventDatabase(context);

        return eventDatabase;
    }
    @Override
    public void onCreate(SQLiteDatabase db2) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + COL_1 + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_2 + " TEXT,"
                + COL_3 + " TEXT,"
                + COL_4 + " TEXT)";

        // at last we are calling a exec sql
        // method to execute above sql query
        db2.execSQL(query);
    }
    public void addNewEvent(String eventName, String eventDate, String eventDetails) {

        // on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.
        SQLiteDatabase db2 = this.getWritableDatabase();

        // on below line we are creating a
        // variable for content values.
        ContentValues values = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        values.put(COL_2, eventName);
        values.put(COL_3, eventDate);
        values.put(COL_4, eventDetails);

        // after adding all values we are passing
        // content values to our table.
        db2.insert(TABLE_NAME, null, values);

        // at last we are closing our
        // database after adding database.
        db2.close();
    }
    public void populateEventListArray()
    {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null))
        {
            if(result.getCount() != 0)
            {
                while (result.moveToNext())
                {
                    int id = result.getInt(1);
                    String name = result.getString(2);
                    String date = result.getString(3);
                    String details = result.getString(4);
                    Event event = new Event(id,name,date,details);
                    Event.eventArrayList.add(event);
                }
            }
        }
    }
    @Override
    public void onUpgrade(SQLiteDatabase db2, int oldVersion, int newVersion) {
        db2.execSQL("DROP TABLE IF EXISTS Event");
        onCreate(db2);
    }


}