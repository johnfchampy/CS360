package com.zybooks.johnchampy_option2_eventtracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

public class DashboardFragment extends AppCompatActivity {
    private ListView eventListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_dashboard);
        initWidgets();
//        loadFromDBToMemory();
        setEventAdapter();
        setOnClickListener();
    }
    private void initWidgets()
    {
        eventListView = findViewById(R.id.eventListView);
    }

//    private void loadFromDBToMemory()
//    {
//        EventDatabase eventDatabase = EventDatabase.instanceOfDatabase(this);
//        eventDatabase.populateEventListArray();
//    }

    private void setEventAdapter()
    {
        EventAdapter eventAdapter = new EventAdapter(getApplicationContext(), Event.nonDeletedEvents());
        eventListView.setAdapter(eventAdapter);
    }
    private void setOnClickListener()
    {
        eventListView.setOnItemClickListener((adapterView, view, position, l) -> {
            Event selectedEvent = (Event) eventListView.getItemAtPosition(position);
            Intent editEventIntent = new Intent(getApplicationContext(), EventAdd.class);
            editEventIntent.putExtra(Event.NOTE_EDIT_EXTRA, selectedEvent.getID());
            startActivity(editEventIntent);
        });
    }
    public void newEvent(View view)
    {
        Intent newEventIntent = new Intent(this, EventAdd.class);
        startActivity(newEventIntent);
    }
    @Override
    protected void onResume()
    {
        super.onResume();
        setEventAdapter();
    }
}