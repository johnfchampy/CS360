package com.zybooks.johnchampy_option2_eventtracker;

import java.util.ArrayList;
import java.util.Date;

public class Event
{
    public static ArrayList<Event> eventArrayList = new ArrayList<>();
    public static String NOTE_EDIT_EXTRA =  "eventEdit";

    private int ID;
    private String EventName;
    private String Date;
    private String Details;
    private Date deleted;

    public Event(int id, String eventname, String date, String details)
    {
        this.Date = date;
        this.EventName = eventname;
        this.Details = details;
        this.deleted = deleted;
        this.ID = id;
    }


    public static Event getEventID(int passedEventID)
    {
        for (Event event : eventArrayList)
        {
            if(event.getID() == passedEventID)
                return event;
        }

        return null;
    }

    public static ArrayList<Event> nonDeletedEvents()
    {
        ArrayList<Event> nonDeleted = new ArrayList<>();
        for(Event event : eventArrayList)
        {
            if(event.getDeleted() == null)
                nonDeleted.add(event);
        }

        return nonDeleted;
    }

    public String getDate()
    {
        return Date;
    }

    public void setDate(String date)
    {
        this.Date = date;
    }
    public int getID()
    {
        return ID;
    }

    public void setID(int id)
    {
        this.ID = id;
    }

    public String getEventName()
    {
        return EventName;
    }

    public void setEventName(String eventName)
    {
        this.EventName = eventName;
    }

    public String getDetails()
    {
        return Details;
    }

    public void setDetails(String details)
    {
        this.Details = details;
    }

    public Date getDeleted()
    {
        return deleted;
    }

    public void setDeleted(Date deleted)
    {
        this.deleted = deleted;
    }
}
