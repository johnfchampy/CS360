package com.zybooks.johnchampy_option2_eventtracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AddFragment extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_add);

        EditText username = findViewById(R.id.editTextInputUsername);
        EditText password = findViewById(R.id.editTextInputPassword);
        Button newUser = findViewById(R.id.buttonSaveUser);
        TextView loginText = findViewById(R.id.editTextInputUsername);
        Database database = new Database(this);

        loginText.setOnClickListener(view -> {
            Intent intent = new Intent(AddFragment.this, MainActivity.class);
            startActivity(intent);
        });


        newUser.setOnClickListener(view -> {
            String user = username.getText().toString().trim();
            String pass = password.getText().toString().trim();
            if(user.isEmpty() || pass.isEmpty())
            {
                Toast.makeText(AddFragment.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
            }
            else {
                if(database.insertData(user,pass))
                {
                    Toast.makeText(AddFragment.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(AddFragment.this, DashboardFragment.class);
                    intent.putExtra("USERNAME", user);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(AddFragment.this, "Username already exists", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
