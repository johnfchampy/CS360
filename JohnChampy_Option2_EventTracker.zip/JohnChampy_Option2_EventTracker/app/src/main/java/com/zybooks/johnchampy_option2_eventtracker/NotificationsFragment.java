package com.zybooks.johnchampy_option2_eventtracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class NotificationsFragment extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private TextView notificationMessage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_notifications);

        notificationMessage = findViewById(R.id.notification_message);
        checkSmsPermission();
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            notificationMessage.setVisibility(View.VISIBLE);
            notificationMessage.setText("You will receive upcoming Event notifications.");
        } else {
            notificationMessage.setVisibility(View.GONE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                notificationMessage.setVisibility(View.VISIBLE);
                notificationMessage.setText("You will receive upcoming Event notifications.");
            } else {
                notificationMessage.setVisibility(View.GONE);
            }
        }
    }
}