package com.zybooks.johnchampy_option2_eventtracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EventAdd extends AppCompatActivity
{
    private EditText eventName, eventDate, eventDetails;
    private EventDatabase eventDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_eventadd);

        eventName = findViewById(R.id.EventNameInput);
        eventDate = findViewById(R.id.DateInput);
        eventDetails = findViewById(R.id.editTextTextMultiLine);
        Button newEvent = findViewById(R.id.buttonAddEvent);

        eventDatabase = new EventDatabase(EventAdd.this);


        newEvent.setOnClickListener(v -> {
            String event = eventName.getText().toString().trim();
            String date = eventDate.getText().toString().trim();
            String details = eventDetails.getText().toString().trim();

            if(event.isEmpty() && date.isEmpty())
            {
                Toast.makeText(EventAdd.this, "Please enter Event Name and Date", Toast.LENGTH_SHORT).show();
                return;
            }
            eventDatabase.addNewEvent(event, date, details);
            // after adding the data we are displaying a toast message.
            Toast.makeText(EventAdd.this, "Event has been added!", Toast.LENGTH_SHORT).show();
            eventName.setText("");
            eventDate.setText("");
            eventDetails.setText("");
            Intent intent = new Intent(EventAdd.this, DashboardFragment.class);
            startActivity(intent);
            finish();

        });

    }
}