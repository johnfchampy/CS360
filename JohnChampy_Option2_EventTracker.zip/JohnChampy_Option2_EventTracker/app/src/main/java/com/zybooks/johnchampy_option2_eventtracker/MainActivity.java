package com.zybooks.johnchampy_option2_eventtracker;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        TextView username = findViewById(R.id.textUser);
        TextView password = findViewById(R.id.textPassword);
        Button loginbtn = findViewById(R.id.buttonLogin);
        Button newUser = findViewById(R.id.buttonNew);
        Database database = new Database(this);


        loginbtn.setOnClickListener(v -> {
            if(username.getText().toString().isEmpty() || password.getText().toString().isEmpty())
            {
                Toast.makeText(MainActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
            }
            else {
                String loggedInUserName = database.checkLogin(username.getText().toString(),password.getText().toString());
                if(loggedInUserName!=null)
                {

                    Intent intent = new Intent(MainActivity.this, DashboardFragment.class);
                    intent.putExtra("USERNAME", loggedInUserName);
                    startActivity(intent);
                    finish();
                }
                else {
                    Toast.makeText(MainActivity.this, "Invalid Username", Toast.LENGTH_SHORT).show();
                }
            }
        });
        newUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddFragment.class);
                startActivity(intent);
            }
        });

    };

}